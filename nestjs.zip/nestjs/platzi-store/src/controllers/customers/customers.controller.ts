import { Controller } from '@nestjs/common';

@Controller('customers')
export class CustomersController {}
