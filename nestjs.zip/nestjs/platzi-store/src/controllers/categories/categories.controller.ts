import { Controller } from '@nestjs/common';

@Controller('categories')
export class CategoriesController {}
