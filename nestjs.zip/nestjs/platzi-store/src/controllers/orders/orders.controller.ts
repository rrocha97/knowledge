import { Controller } from '@nestjs/common';

@Controller('orders')
export class OrdersController {}
