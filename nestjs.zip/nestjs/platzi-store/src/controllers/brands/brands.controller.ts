import { Controller } from '@nestjs/common';

@Controller('brands')
export class BrandsController {}
