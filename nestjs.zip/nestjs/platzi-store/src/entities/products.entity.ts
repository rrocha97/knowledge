export class Products {
  id: number;
  name: string;
  stock: number;
}
